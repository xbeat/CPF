# CPF Indicators Examples

This document provides sample indicators from each of the 10 CPF categories to illustrate the assessment methodology.

## Category 1: Authority & Obedience Dynamics (Milgram-based)

**Theoretical basis:** Milgram (1974) demonstrated that 65% of participants would administer potentially lethal shocks when instructed by authority figures.

**Sample Indicators:**

1. **Unquestioning Compliance**
   - Green: Security policies are discussed and challenged constructively
   - Yellow: Some reluctance to question authority decisions
   - Red: Blind obedience to directives, even when security implications unclear

2. **Chain of Command Rigidity**
   - Green: Flexible escalation paths for security concerns
   - Yellow: Some bureaucratic barriers to reporting
   - Red: Strict hierarchies prevent junior staff from raising security issues

3. **Expert Authority Deference**
   - Green: Vendor claims are critically evaluated
   - Yellow: Occasional over-reliance on vendor security assertions
   - Red: Automatic acceptance of vendor/consultant recommendations

## Category 2: Unconscious Group Dynamics (Bion-based)

**Theoretical basis:** Bion (1961) identified three basic assumptions groups adopt under anxiety: Dependency, Fight-Flight, Pairing.

**Sample Indicators:**

1. **Dependency Assumption (baD)**
   - Green: Balanced view of security tools and leadership
   - Yellow: Some expectation that technology alone will solve problems
   - Red: Over-reliance on "silver bullet" solutions or omnipotent security leader

2. **Fight-Flight Assumption (baF)**
   - Green: Threats assessed realistically, both internal and external
   - Yellow: Tendency to focus primarily on external threats
   - Red: Aggressive perimeter defense while ignoring insider threats completely

3. **Pairing Assumption (baP)**
   - Green: Realistic expectations about new security initiatives
   - Yellow: Some hope that next tool/methodology will solve all issues
   - Red: Continuous acquisition of new solutions without addressing fundamentals

## Category 3: Object Relations & Splitting (Klein-based)

**Theoretical basis:** Klein (1946) described splitting as dividing objects into "all good" or "all bad" to manage anxiety.

**Sample Indicators:**

1. **Insider Idealization**
   - Green: Realistic assessment of insider threat potential
   - Yellow: Some assumption that internal staff are inherently trustworthy
   - Red: Complete trust in employees, outsiders viewed as only threat

2. **Legacy System Attachment**
   - Green: Objective evaluation of legacy vs. new systems
   - Yellow: Some resistance to replacing familiar systems
   - Red: Legacy systems viewed as "good/safe," new requirements as "threatening"

3. **Threat Externalization**
   - Green: Vulnerabilities acknowledged as both internal and external
   - Yellow: Some tendency to blame external actors for all incidents
   - Red: All organizational weaknesses projected onto "sophisticated attackers"

## Category 4: Attachment & Trust Patterns (Bowlby-based)

**Theoretical basis:** Bowlby (1969) demonstrated how early attachment patterns influence adult relationships and trust.

**Sample Indicators:**

1. **Zero-Trust Implementation**
   - Green: Principle of least privilege consistently applied
   - Yellow: Some exceptions made for "trusted" individuals/departments
   - Red: Security controls bypassed for senior management or "key" staff

2. **Vendor Relationship Patterns**
   - Green: Healthy skepticism with vendors while maintaining collaboration
   - Yellow: Either excessive trust or excessive suspicion of vendors
   - Red: Anxious attachment to specific vendors, panic when switching

3. **Inter-Departmental Trust**
   - Green: Constructive collaboration with security checks
   - Yellow: Some departments view security as "enemy"
   - Red: Deep mistrust between security and other departments

## Category 5: Shadow & Archetypal Dynamics (Jung-based)

**Theoretical basis:** Jung (1969) described the Shadow as unacknowledged aspects of the psyche projected onto others.

**Sample Indicators:**

1. **Shadow Projection**
   - Green: Organization acknowledges its own security weaknesses
   - Yellow: Some unacknowledged vulnerabilities
   - Red: All security failures attributed to external "evil hackers"

2. **Trickster Archetype Recognition**
   - Green: Social engineering understood as exploiting human nature
   - Yellow: Some awareness but limited training
   - Red: Social engineering viewed as purely technical problem

3. **Collective Unconscious Patterns**
   - Green: Cultural assumptions about security critically examined
   - Yellow: Some unquestioned cultural security assumptions
   - Red: Deep cultural beliefs about security never questioned

## Category 6: Cognitive Biases & Heuristics (Kahneman-based)

**Theoretical basis:** Kahneman (2011) demonstrated systematic deviations from rational decision-making.

**Sample Indicators:**

1. **Availability Bias**
   - Green: Risk assessment based on comprehensive data
   - Yellow: Recent incidents somewhat overweighted in planning
   - Red: Security strategy driven primarily by last major incident

2. **Confirmation Bias**
   - Green: Security hypotheses rigorously tested and challenged
   - Yellow: Some tendency to seek confirming evidence
   - Red: Only evidence supporting existing beliefs considered

3. **Sunk Cost Fallacy**
   - Green: Willingness to abandon ineffective security investments
   - Yellow: Some reluctance to change course on failing initiatives
   - Red: Continued investment in failed security programs because of past spending

## Category 7: Social Influence & Persuasion (Cialdini-based)

**Theoretical basis:** Cialdini (2007) identified six principles of persuasion: reciprocity, commitment, social proof, authority, liking, scarcity.

**Sample Indicators:**

1. **Reciprocity Vulnerability**
   - Green: Staff trained to recognize reciprocity manipulation
   - Yellow: Some awareness but inconsistent application
   - Red: Common pattern of accepting gifts/favors before security decisions

2. **Social Proof Susceptibility**
   - Green: Security decisions based on organizational needs
   - Yellow: Some influence from "what others are doing"
   - Red: Security strategy primarily driven by peer company actions

3. **Scarcity Manipulation**
   - Green: Urgency claims critically evaluated
   - Yellow: Some rushed decisions under artificial time pressure
   - Red: Regular pattern of security decisions made under manufactured urgency

## Category 8: Stress & Decision-Making (Neurobiological)

**Theoretical basis:** Selye (1956) and LeDoux (2000) demonstrated how stress impairs cognitive function and activates emotional circuits.

**Sample Indicators:**

1. **Chronic Stress Levels**
   - Green: Manageable workload, thoughtful security decisions
   - Yellow: Periodic stress affecting decision quality
   - Red: Chronic understaffing leading to reactive security decisions

2. **Cognitive Load Management**
   - Green: Security processes designed within cognitive limits (Miller, 1956)
   - Yellow: Some unnecessarily complex security procedures
   - Red: Security requirements exceed cognitive capacity (7±2 rule violated)

3. **System 1 Dominance**
   - Green: Time allocated for deliberate (System 2) security thinking
   - Yellow: Some time-pressured security decisions
   - Red: Most security decisions made under time pressure (fast System 1)

## Category 9: Digital Psychology & Transitional Space (Winnicott-based)

**Theoretical basis:** Winnicott (1971) described transitional space as neither fully real nor fully imaginary.

**Sample Indicators:**

1. **Virtual Reality Perception**
   - Green: Digital environments treated with appropriate caution
   - Yellow: Some blurred boundaries between digital and physical risks
   - Red: Digital interactions seen as "not real," lowering guard

2. **Online Disinhibition**
   - Green: Professional conduct standards enforced digitally
   - Yellow: Some relaxed behavior in digital communications
   - Red: Significantly different (risky) behavior in digital vs. physical contexts

3. **Avatar/Identity Confusion**
   - Green: Clear understanding of digital identity management
   - Yellow: Some confusion about digital persona boundaries
   - Red: Significant blurring of personal/professional digital identities

## Category 10: AI-Human Interaction Psychology

**Theoretical basis:** Emerging research on human-AI trust, automation bias, and anthropomorphization.

**Sample Indicators:**

1. **AI Over-Trust**
   - Green: AI outputs critically evaluated by humans
   - Yellow: Some tendency to trust AI recommendations without verification
   - Red: Automatic acceptance of AI security decisions

2. **Automation Complacency**
   - Green: Human oversight maintained on automated security
   - Yellow: Periodic lapses in monitoring automated systems
   - Red: Complete reliance on automation without human verification

3. **Anthropomorphization**
   - Green: AI tools understood as algorithms, not intelligent beings
   - Yellow: Some attribution of human-like understanding to AI
   - Red: Treating AI security tools as if they have human judgment

## Assessment Methodology

**Data Collection Methods:**
- Anonymous organizational surveys
- Aggregated communication pattern analysis
- Incident response workflow review
- Decision-making process observation
- Training effectiveness metrics

**Privacy Principles:**
- Never profile individuals
- Aggregate patterns only
- Focus on organizational dynamics
- Transparent methodology
- Ethical review board oversight

## Scoring Guidelines

Each indicator scored on ternary scale:
- **Green (1 point)**: Healthy patterns, low vulnerability
- **Yellow (2 points)**: Some concerning patterns, medium vulnerability  
- **Red (3 points)**: Significant vulnerabilities, high risk

**Category Scores:**
- 10-15 points: Low risk category
- 16-20 points: Medium risk category
- 21-30 points: High risk category

**Overall CPF Score:**
- 100-150 points: Low organizational vulnerability
- 151-200 points: Medium organizational vulnerability
- 201-300 points: High organizational vulnerability
