# CPF Theoretical Foundations - Detailed

This document provides comprehensive theoretical background for the Cybersecurity Psychology Framework.

## Core Thesis

**Traditional security awareness fails because it targets conscious decision-making, while neuroscience demonstrates that decisions occur 300-500ms before conscious awareness (Libet, 1983; Soon, 2008).**

CPF addresses this gap by mapping pre-cognitive psychological states to security vulnerabilities.

## The Pre-Cognitive Gap

### Neuroscience Evidence

**Libet's Experiments (1983)**
- Measured brain activity (readiness potential) before conscious decision
- Found 300-500ms delay between neural activity and conscious awareness
- Implication: Decisions substantially pre-determined by unconscious processes

**Soon et al. (2008)**
- fMRI studies predicted decisions up to 10 seconds before consciousness
- Located predictive activity in frontopolar and parietal cortex
- Conclusion: "Free" decisions have unconscious determinants

**LeDoux's Emotional Pathways (2000)**
- Amygdala (threat response) activates before prefrontal cortex (rational analysis)
- "Low road" (thalamus → amygdala) bypasses cortical processing
- Security threats trigger emotional responses before rational evaluation

### Implications for Cybersecurity

Traditional training assumes:
1. Information → Awareness → Rational choice → Secure behavior

Reality:
1. Unconscious pattern recognition → Pre-cognitive decision → Post-hoc rationalization

**Example:** Phishing susceptibility determined more by:
- Current stress levels (cortisol)
- Organizational anxiety (group dynamics)
- Authority relationship with sender
- Time pressure (System 1 activation)

Than by:
- Knowledge of phishing techniques
- Conscious risk assessment
- Deliberate decision-making

## Psychoanalytic Foundations

### Bion's Group Dynamics (1961)

**Work Group vs. Basic Assumption Group**

**Work Group:**
- Task-oriented
- Reality-based
- Rational cooperation
- Effective security practices

**Basic Assumption Group:**
- Unconscious assumptions dominate
- Anxiety-driven
- Reality-distorting
- Creates security vulnerabilities

**Three Basic Assumptions:**

**1. Dependency (baD)**
- Unconscious fantasy: Omnipotent leader/solution will provide perfect protection
- Manifests as: Over-reliance on security vendors, "silver bullet" seeking
- Vulnerability: Abdication of security responsibility to external sources
- Example: "We hired a CISO, security is their problem now"

**2. Fight-Flight (baF)**
- Unconscious fantasy: Threats are external enemies requiring combat or avoidance
- Manifests as: Aggressive perimeter defense, insider threat denial
- Vulnerability: Ignoring internal vulnerabilities while fortifying perimeter
- Example: "We need stronger firewalls" (while ignoring insider access controls)

**3. Pairing (baP)**
- Unconscious fantasy: Future solution will save organization
- Manifests as: Continuous tool acquisition without addressing fundamentals
- Vulnerability: Never implementing current tools effectively
- Example: "The new SIEM/EDR/AI tool will finally solve our problems"

**CPF Application:**
Assessment questions probe for basic assumption dominance over work group functioning.

### Klein's Object Relations (1946)

**Splitting Defense Mechanism**

Under anxiety, objects divided into:
- **Good objects**: Idealized, trusted, familiar
- **Bad objects**: Demonized, threatening, unfamiliar

**In Cybersecurity Context:**

**Splitting Pattern 1: Internal vs. External**
- Good: Trusted employees, "our people"
- Bad: External hackers, attackers
- Vulnerability: Insider threat blindness
- Reality: Insiders responsible for 60% of breaches

**Splitting Pattern 2: Legacy vs. New**
- Good: Familiar legacy systems, "proven" technology
- Bad: New security requirements, "disruptive" changes
- Vulnerability: Outdated systems maintained despite vulnerabilities
- Reality: Unpatched legacy systems primary attack vector

**Splitting Pattern 3: Us vs. Security Team**
- Good: "Productive" business units
- Bad: "Obstructionist" security team
- Vulnerability: Security requirements bypassed
- Reality: Security team protecting organizational interests

**Projection Mechanism**

Unacknowledged internal qualities projected onto external objects.

**Cybersecurity Projection:**
- Organizational vulnerabilities → Projected onto "sophisticated attackers"
- Internal security failures → Attributed to "advanced persistent threats"
- Management's security negligence → Blamed on "impossible to prevent" attacks

**Reality Check:**
Most breaches exploit basic vulnerabilities (unpatched systems, weak passwords, missing MFA), not sophisticated zero-days.

### Winnicott's Transitional Space (1971)

**Definition:** Psychological space between inner and outer reality, neither fully subjective nor objective.

**Digital Environments as Transitional Space:**

Traditional space: Physical | Clearly real
Transitional space: Digital | Real and not-real simultaneously
Internal space: Imagination | Clearly not-real

**Cybersecurity Implications:**

1. **Reduced Reality Perception**
   - Digital actions feel less "real" than physical actions
   - Lowers psychological barriers to risky behavior
   - Example: Sharing sensitive data digitally feels less serious than handing physical documents

2. **Online Disinhibition Effect**
   - Different behavior online vs. offline
   - Professional boundaries relaxed in digital communication
   - Vulnerability: Information disclosure via email/chat that would never occur face-to-face

3. **Avatar/Identity Confusion**
   - Digital personas feel separate from "real" self
   - Professional/personal boundaries blur
   - Vulnerability: Using work systems for personal activities, vice versa

### Jung's Analytical Psychology (1969)

**Shadow Archetype**

The Shadow: Unacknowledged, repressed aspects of personality/organization.

**Organizational Shadow:**
- Acknowledged: "We have strong security controls"
- Shadow (denied): Unpatched systems, unenforced policies, security theater

**Shadow Projection in Security:**
- Organization's vulnerabilities → Projected onto external "evil hackers"
- Internal security failures → Attributed to sophisticated attacks
- Management negligence → Blamed on unpredictable threats

**Integration vs. Projection:**
- Mature security: Acknowledging organizational shadow (vulnerabilities)
- Immature security: Projecting shadow onto external threats

**Trickster Archetype**

The Trickster: Boundary-crosser, deceiver, exploiting rigid systems.

**Social Engineering as Trickster:**
- Exploits rigid hierarchies (Milgram effect)
- Uses organizational assumptions against organization
- Succeeds through psychological manipulation, not technical skill

### Bowlby's Attachment Theory (1969)

**Attachment Patterns:**

**Secure Attachment:**
- Balanced trust and skepticism
- Appropriate risk assessment
- Example: Verify-then-trust approach

**Anxious Attachment:**
- Over-dependency on security vendors/leaders
- Panic when security changes
- Example: Can't switch vendors even when underperforming

**Avoidant Attachment:**
- Dismissing security risks
- Counter-dependency ("we don't need security")
- Example: Resistance to security controls

**Disorganized Attachment:**
- Simultaneously seeking and avoiding security
- Contradictory security policies
- Example: Demanding security but refusing controls

## Cognitive Psychology Foundations

### Kahneman's Dual-Process Theory (2011)

**System 1: Fast**
- Automatic, unconscious
- Pattern-recognition based
- Low cognitive effort
- Error-prone under novel conditions
- Dominant under time pressure/cognitive load

**System 2: Slow**
- Deliberate, conscious
- Analytical reasoning
- High cognitive effort
- Better for novel situations
- Requires time and cognitive resources

**Security Decision Reality:**
- Most decisions made under time pressure → System 1 dominant
- Security training targets System 2 (rational analysis)
- **Gap:** Training System 2 but decisions made by System 1

**Implications:**
Security controls must work WITH System 1 (intuitive, easy) not against it (requiring deliberate thought).

### Key Cognitive Biases in Security

**Availability Heuristic**
- Definition: Judging frequency by ease of recall
- Security impact: Recent breaches overweighted in risk assessment
- Example: Major ransomware attack → Over-investment in ransomware defenses while ignoring other risks

**Confirmation Bias**
- Definition: Seeking information confirming existing beliefs
- Security impact: Security hypotheses never properly tested
- Example: Believing phishing training works → Only noticing successful identifications, ignoring successful attacks

**Authority Bias (Milgram, 1974)**
- Definition: Over-trusting authority figures
- Security impact: Unquestioned acceptance of executive/vendor claims
- Example: CEO email bypass → Automatic trust despite policy violations

**Normalcy Bias**
- Definition: Underestimating disaster likelihood
- Security impact: "It won't happen to us" thinking
- Example: Ignoring breach warnings because "we've never been breached"

**Sunk Cost Fallacy**
- Definition: Continuing failed course due to past investment
- Security impact: Maintaining ineffective security programs
- Example: "We've invested $2M in this SIEM, we must make it work"

### Prospect Theory (Kahneman & Tversky, 1979)

**Loss Aversion:**
- Losses weigh psychologically heavier than equivalent gains
- Security implication: Fear of breach < Resistance to security investment cost

**Framing Effects:**
- Same information, different frame → Different decisions
- Security implication: "Prevent 95% of attacks" vs. "5% of attacks succeed"

### Cognitive Load Theory (Miller, 1956)

**Working Memory Limit: 7±2 items**

**Security Implications:**
- Password requirements exceeding cognitive capacity → Written passwords
- Complex security procedures → Workarounds
- Too many security tools → None used effectively

## Social Psychology Foundations

### Cialdini's Persuasion Principles (2007)

**1. Reciprocity**
- People feel obligated to return favors
- Attack: Small gift → Feel obligated to provide information

**2. Commitment & Consistency**
- People honor past commitments
- Attack: Small initial compliance → Escalating requests

**3. Social Proof**
- People follow others' behavior
- Attack: "Everyone else has updated their information..."

**4. Authority**
- People defer to authority figures
- Attack: Impersonating executives, technical experts

**5. Liking**
- People comply with those they like
- Attack: Building rapport before requests

**6. Scarcity**
- Perceived scarcity increases value/urgency
- Attack: "Urgent: Account will close in 24 hours"

## Stress & Performance

### Selye's Stress Response (1956)

**Three Stages:**
1. Alarm: Initial stress response
2. Resistance: Adaptation to stressor
3. Exhaustion: Resource depletion

**Security Decision Quality:**
- Alarm/Exhaustion: Significantly impaired
- Chronic stress → Persistent exhaustion → Poor security decisions

### Yerkes-Dodson Law

Inverted-U relationship: Performance vs. Arousal
- Too little stress: Under-vigilance
- Optimal stress: Peak performance
- Too much stress: Impaired decisions

**Application:**
Chronically understaffed security teams operate in exhaustion zone → Poor decisions.

## Integration: Why CPF Works

**Traditional Approach:**
Information → Conscious awareness → Rational decision

**CPF Approach:**
Map pre-cognitive states → Predict vulnerability → Prevent exploitation

**Validation Hypothesis:**
Organizations scoring high (Red) on CPF indicators will experience more security incidents than low-scoring (Green) organizations, independent of technical controls.

This validates that psychological states predict security outcomes beyond technical measures.
