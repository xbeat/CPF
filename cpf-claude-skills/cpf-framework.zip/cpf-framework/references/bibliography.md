# CPF Framework - Complete Bibliography

This document contains the complete academic references for the Cybersecurity Psychology Framework.

## Core Psychoanalytic Foundations

**Bion, W. R. (1961).** *Experiences in groups.* London: Tavistock Publications.
- Foundational work on basic assumptions (baD, baF, baP)
- Group dynamics and unconscious processes

**Klein, M. (1946).** Notes on some schizoid mechanisms. *International Journal of Psychoanalysis*, 27, 99-110.
- Object relations theory
- Splitting and projection mechanisms

**Winnicott, D. W. (1971).** *Playing and reality.* London: Tavistock Publications.
- Transitional space concept
- Reality and fantasy boundaries

**Jung, C. G. (1969).** *The Archetypes and the Collective Unconscious.* Princeton: Princeton University Press.
- Shadow archetype
- Collective unconscious patterns

**Bowlby, J. (1969).** *Attachment and Loss: Vol. 1. Attachment.* New York: Basic Books.
- Attachment theory
- Trust patterns in organizations

## Cognitive Psychology & Behavioral Economics

**Kahneman, D. (2011).** *Thinking, fast and slow.* New York: Farrar, Straus and Giroux.
- Dual-process theory (System 1/System 2)
- Cognitive biases and heuristics

**Kahneman, D., & Tversky, A. (1979).** Prospect theory: An analysis of decision under risk. *Econometrica*, 47(2), 263-291.
- Loss aversion
- Decision-making under risk

**Cialdini, R. B. (2007).** *Influence: The psychology of persuasion.* New York: Collins.
- Six principles of persuasion
- Social influence mechanisms

**Miller, G. A. (1956).** The magical number seven, plus or minus two. *Psychological Review*, 63(2), 81-97.
- Cognitive load limits
- Working memory constraints

## Neuroscience Foundations

**Libet, B., Gleason, C. A., Wright, E. W., & Pearl, D. K. (1983).** Time of conscious intention to act in relation to onset of cerebral activity. *Brain*, 106(3), 623-642.
- Pre-conscious decision-making
- 300-500ms delay before awareness

**Soon, C. S., Brass, M., Heinze, H. J., & Haynes, J. D. (2008).** Unconscious determinants of free decisions in the human brain. *Nature Neuroscience*, 11(5), 543-545.
- Neural predictors of decisions
- Unconscious brain activity

**LeDoux, J. (2000).** Emotion circuits in the brain. *Annual Review of Neuroscience*, 23, 155-184.
- Amygdala activation before prefrontal cortex
- Emotional processing pathways

**Damasio, A. (1994).** *Descartes' error: Emotion, reason, and the human brain.* New York: Putnam.
- Somatic markers
- Emotion's role in decision-making

## Organizational Psychology

**Kernberg, O. (1998).** *Ideology, conflict, and leadership in groups and organizations.* New Haven: Yale University Press.
- Organizational dynamics
- Leadership and group processes

**Menzies Lyth, I. (1960).** A case-study in the functioning of social systems as a defence against anxiety. *Human Relations*, 13, 95-121.
- Social defense systems
- Organizational anxiety management

**Milgram, S. (1974).** *Obedience to authority.* New York: Harper & Row.
- Authority compliance mechanisms
- Hierarchical obedience patterns

## Cybersecurity Human Factors

**Verizon. (2023).** *2023 Data Breach Investigations Report.* Verizon Enterprise.
- 85% of breaches involve human factors
- Attack vector statistics

**Gartner. (2023).** *Forecast: Information Security and Risk Management, Worldwide, 2021-2027.* Gartner Research.
- Global cybersecurity spending data
- Market trends and projections

**SANS Institute. (2023).** *Security Awareness Report 2023.* SANS Security Awareness.
- Current security awareness program effectiveness
- Training methodology limitations

**Beautement, A., Sasse, M. A., & Wonham, M. (2008).** The compliance budget: Managing security behaviour in organisations. *Proceedings of NSPW*, 47-58.
- Cognitive load in security decisions
- Compliance burden effects

## Behavioral Theory

**Ajzen, I. (1991).** The theory of planned behavior. *Organizational Behavior and Human Decision Processes*, 50(2), 179-211.
- Rational actor assumptions
- Behavior prediction models

**Selye, H. (1956).** *The stress of life.* New York: McGraw-Hill.
- Stress response mechanisms
- Performance under pressure

## Citation Practices

When citing CPF framework:

**For the framework itself:**
Canale, G. (2025). The Cybersecurity Psychology Framework: A Pre-Cognitive Vulnerability Assessment Model Integrating Psychoanalytic and Cognitive Sciences. *Preprint*. https://cpf3.org

**For specific theoretical components:**
Reference the original authors (e.g., Bion, 1961; Kahneman, 2011) as integrated within CPF.

## Chronological Evolution

1. **1940s-1970s**: Psychoanalytic foundations (Klein, Bion, Winnicott, Jung)
2. **1960s-1980s**: Cognitive psychology emergence (Miller, Milgram)
3. **1980s-1990s**: Neuroscience of decision-making (Libet, Damasio)
4. **1970s-2000s**: Behavioral economics (Kahneman, Tversky)
5. **2000s-2020s**: Organizational security human factors
6. **2025**: CPF integration of all domains
