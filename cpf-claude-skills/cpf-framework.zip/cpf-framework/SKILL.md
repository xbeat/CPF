---
name: cpf-framework
description: The Cybersecurity Psychology Framework (CPF) - use when creating presentations, documents, assessments, or materials about the CPF framework, its theoretical foundations (psychoanalysis, cognitive psychology), vulnerability assessment methodology, or human factors in cybersecurity. Triggers on mentions of CPF, psychological vulnerabilities, pre-cognitive processes, or security awareness psychology.
---

# Cybersecurity Psychology Framework (CPF)

## Overview

The Cybersecurity Psychology Framework (CPF) is an interdisciplinary model that identifies pre-cognitive vulnerabilities in organizational security through systematic integration of psychoanalytic theory and cognitive psychology. Unlike traditional security awareness, CPF maps unconscious psychological states to specific attack vectors for predictive security strategies.

**Author:** Giuseppe Canale, CISSP  
**Website:** https://cpf3.org  
**Status:** Pre-publication research framework

## Core Theoretical Foundations

### Psychoanalytic Contributions

**Bion's Basic Assumptions** (Bion, 1961)
- **Dependency (baD)**: Over-reliance on omnipotent leaders/technology
- **Fight-Flight (baF)**: Perceiving threats as external enemies
- **Pairing (baP)**: Hoping for future salvation through new solutions

**Kleinian Object Relations** (Klein, 1946)
- Splitting: Dividing into "all good" (trusted insiders) vs "all bad" (external attackers)
- Projection: Organizational vulnerabilities projected onto sophisticated attackers
- Idealization/Demonization: Legacy systems (familiar/good) vs new requirements (threatening/bad)

**Winnicott's Transitional Space** (Winnicott, 1971)
- Digital environments as neither fully real nor imaginary
- Creates unique psychological vulnerabilities

**Jungian Archetypes** (Jung, 1969)
- Shadow: Unacknowledged organizational vulnerabilities
- Trickster: Social engineering exploits

### Cognitive Psychology Foundations

**Kahneman's Dual Systems** (Kahneman, 2011)
- System 1: Fast, automatic, dominates under time pressure
- System 2: Slow, deliberate, impaired under cognitive load

**Key Cognitive Biases**
- Availability heuristic: Recent events overweighted
- Confirmation bias: Seeking information confirming beliefs
- Authority bias: Deferring to perceived experts (Milgram, 1974)
- Sunk cost fallacy: Continuing failed security investments
- Normalcy bias: Underestimating disaster likelihood

**Prospect Theory** (Kahneman & Tversky, 1979)
- Loss aversion in risk decisions
- Framing effects on security choices

## Framework Architecture

### Structure
- **100 indicators** across **10 categories**
- **Ternary assessment system**: Green (low risk) / Yellow (medium risk) / Red (high risk)
- **Privacy-preserving**: Aggregated behavioral patterns, never individual profiling

### The 10 Categories

1. **Authority & Obedience Dynamics** (Milgram-based)
2. **Unconscious Group Dynamics** (Bion-based)
3. **Object Relations & Splitting** (Klein-based)
4. **Attachment & Trust Patterns** (Bowlby-based)
5. **Shadow & Archetypal Dynamics** (Jung-based)
6. **Cognitive Biases & Heuristics** (Kahneman-based)
7. **Social Influence & Persuasion** (Cialdini-based)
8. **Stress & Decision-Making** (Neurobiological)
9. **Digital Psychology & Transitional Space** (Winnicott-based)
10. **AI-Human Interaction Psychology** (Emerging field)

### Assessment Methodology

**Ternary Rating System:**
- **Green**: Healthy organizational dynamics, low vulnerability
- **Yellow**: Some concerning patterns, medium vulnerability
- **Red**: Significant psychological vulnerabilities, high risk

**Data Sources (Privacy-Preserving):**
- Aggregated communication patterns
- Organizational structure dynamics
- Decision-making processes
- Incident response patterns
- Training effectiveness metrics

## Terminology Standards

### Key Terms (always use these consistently)

- **Pre-cognitive processes**: Psychological mechanisms occurring before conscious awareness (300-500ms prior)
- **Basic assumptions**: Bion's unconscious group states (baD, baF, baP)
- **Splitting**: Klein's defense mechanism dividing objects into all-good/all-bad
- **System 1/System 2**: Kahneman's dual-process model of cognition
- **Vulnerability indicators**: Observable patterns correlating with security risks
- **Ternary assessment**: Three-level (Green/Yellow/Red) risk evaluation

### Avoid These Terms
- "Personality profiling" (CPF never profiles individuals)
- "Psychological testing" (CPF assesses organizational patterns)
- "Unconscious bias training" (too limited, misses depth)
- "Security awareness" alone (insufficient without pre-cognitive understanding)

## Content Creation Guidelines

### When Creating Documents/Presentations

**Structure Principles:**
1. Start with the gap: Traditional security awareness fails because decisions occur pre-cognitively
2. Establish theoretical credibility: Reference primary sources (Bion, Klein, Kahneman)
3. Bridge theory to practice: Show how unconscious patterns create specific vulnerabilities
4. Present methodology: 10 categories, 100 indicators, ternary system
5. Address ethics: Privacy-preserving, non-individual approach

**Tone:**
- Academic yet accessible
- Interdisciplinary (respecting both cybersecurity and psychology)
- Evidence-based (cite neuroscience, behavioral economics)
- Practical applications emphasized
- Acknowledge limitations and future research needs

**Visual Elements:**
- Use diagrams for the 10 categories
- Show theoretical lineage (Bion → Klein → Winnicott → Kahneman → CPF)
- Include example indicators per category
- Visualize ternary assessment system
- Timeline graphics for research phases

### Key Messages to Emphasize

1. **85% of breaches involve human factors** yet current approaches target only conscious level
2. **Decisions occur 300-500ms before awareness** (neuroscience evidence)
3. **Organizations develop unconscious defense systems** that create blind spots
4. **CPF is predictive, not reactive** - identifies vulnerabilities before exploitation
5. **Privacy-preserving by design** - patterns not profiles

## Reference Materials

For detailed information, consult:
- `references/theoretical_foundations.md` - Complete psychoanalytic and cognitive theories
- `references/bibliography.md` - Full academic citations and sources
- `references/indicators_examples.md` - Sample indicators from each category

## Common Use Cases

**"Create a presentation about CPF for a security conference"**
- Focus on novel interdisciplinary approach
- Emphasize pre-cognitive vulnerability identification
- Include concrete examples of each category
- Address privacy and ethical considerations

**"Write an executive summary of the CPF framework"**
- 2-3 pages maximum
- Lead with business case (breach costs, human factor statistics)
- Explain theoretical innovation concisely
- Present implementation approach
- Include ROI considerations

**"Generate assessment questions for Category X"**
- Ensure questions probe unconscious patterns not conscious beliefs
- Use behavioral indicators not self-reports
- Maintain privacy-preserving aggregation
- Align with theoretical foundations

**"Create a white paper on CPF methodology"**
- Comprehensive theoretical background
- Detailed methodology section
- Literature review positioning CPF
- Future research roadmap
- Academic tone with practical applications
