---
name: cpf-implementation
description: Technical implementation guide for operationalizing CPF in SOC environments. Use when developing technical deployment documentation, writing algorithm specifications, creating detection logic, implementing SIEM/SOAR integrations, or building operational security capabilities based on CPF indicators. Triggers on "implementation", "SOC deployment", "detection algorithms", "SIEM integration", "operationalize CPF", or technical engineering requests.
---

# CPF Implementation - Technical Operations Skill

## Overview

This skill provides comprehensive technical guidance for operationalizing the Cybersecurity Psychology Framework's 100 indicators into functioning Security Operations Center (SOC) capabilities. It covers the OFTLISRV implementation schema, mathematical detection formulations, data source integrations, and response protocols.

## When to Use This Skill

**Use cpf-implementation when:**
- Deploying CPF in SOC environments
- Writing detection algorithm specifications
- Integrating CPF with SIEM/SOAR platforms
- Developing technical implementation documentation
- Creating data collection architectures
- Designing response automation
- Building monitoring dashboards

**Use cpf-framework when:**
- General CPF overview and communications
- Business presentations
- Executive summaries

**Use cpf-academic when:**
- Writing research papers
- Academic presentations
- Theoretical discussions

## OFTLISRV Implementation Schema

The core methodology for operationalizing each CPF indicator follows the systematic OFTLISRV schema:

### Schema Components

**O - Observables**
- Concrete, measurable phenomena that manifest psychological states
- Must be quantifiable from existing data sources
- Examples: compliance_rate, decision_time, error_frequency

**F - Data Sources (From)**
- Specific systems providing telemetry
- Examples: Active Directory logs, email gateway, SIEM, endpoint detection
- Must already exist in target environment

**T - Temporality**
- Sampling frequency, observation windows, persistence thresholds
- Defines temporal behavior of indicators
- Critical for psychological phenomena with decay patterns

**L - Detection Logic**
- Mathematical formulations combining rules, anomaly detection, correlation
- Specific algorithms and thresholds
- Combines deterministic and statistical approaches

**I - Interdependencies**
- Relationships with other indicators
- Bayesian network connections
- Amplification and masking effects

**S - Thresholds (Severity)**
- Green/Yellow/Red severity boundaries
- Calibrated per organization during baseline
- Dynamic adjustment based on context

**R - Response Protocols**
- Graduated escalation based on severity
- Automated, semi-automated, manual responses
- Integration with existing incident response

**V - Validation**
- Continuous accuracy assessment
- Synthetic testing procedures
- Drift detection and recalibration

## Universal Detection Framework

### Base Detection Function

Each indicator employs the universal detection function:

$$D_i = w_1 \cdot R_i + w_2 \cdot A_i + w_3 \cdot C_i$$

Where:
- $D_i$ = Detection score for indicator $i$
- $R_i$ = Rule-based detection (binary: 0 or 1)
- $A_i$ = Anomaly score (continuous: 0 to 1)
- $C_i$ = Contextual correlation (normalized: 0 to 1)
- $w_1, w_2, w_3$ = Calibrated weights (sum to 1)

**Weight Calibration:**
During baseline period (typically 30 days):
- Collect ground truth incidents
- Optimize weights using logistic regression
- Validate on hold-out set
- Adjust per category based on data availability

### Temporal State Modeling

Psychological indicators exhibit persistence and decay:

$$T_i(t) = \alpha \cdot X_i(t) + (1-\alpha) \cdot T_i(t-1)$$

Where:
- $T_i(t)$ = Temporal state at time $t$
- $X_i(t)$ = Instantaneous observation
- $\alpha = e^{-\Delta t/\tau}$ = Decay factor
- $\tau$ = Persistence threshold (indicator-specific)
- $\Delta t$ = Time since last observation

**Temporal Parameters by Category:**
- Authority indicators: $\tau = 3600s$ (1 hour persistence)
- Stress indicators: $\tau = 7200s$ (2 hour persistence)
- Cognitive load: $\tau = 1800s$ (30 min persistence)
- Group dynamics: $\tau = 86400s$ (24 hour persistence)

### Anomaly Detection via Mahalanobis Distance

Accounts for correlation between observables:

$$A_i = \sqrt{(x_i - \mu_i)^T \Sigma_i^{-1} (x_i - \mu_i)}$$

Where:
- $x_i$ = Observation vector
- $\mu_i$ = Baseline mean vector
- $\Sigma_i$ = Covariance matrix
- Updated via exponential weighted moving average (EWMA)

**Covariance Update:**
$$\Sigma_i(t) = \lambda \cdot \Sigma_i(t-1) + (1-\lambda) \cdot (x_i - \mu_i)(x_i - \mu_i)^T$$

Typical $\lambda = 0.95$ (5% weight to new observations)

## Category-Specific Implementations

### Category 1: Authority-Based Vulnerabilities

**Data Sources:**
- Active Directory authentication logs
- Exchange message tracking logs
- Privileged Access Management (PAM) systems
- Approval workflow systems

**Key Indicator: 1.1 Unquestioning Compliance**

*Observable:*
Compliance rate $C_r = \frac{N_{executed}}{N_{requested}}$ where requests originate from authority domains

*Detection Logic:*
```
IF (C_r > μ_baseline + 2σ) AND (window = 3600s) THEN
    Yellow threshold exceeded
IF (C_r > μ_baseline + 3σ) THEN
    Red threshold exceeded
```

*Data Extraction:*
```sql
SELECT 
    sender_domain,
    COUNT(*) as requests,
    SUM(CASE WHEN action_taken THEN 1 ELSE 0 END) as executed,
    (executed / requests) as compliance_rate
FROM email_logs
WHERE sender_domain IN ('exec_domains')
    AND action_keywords IN ('transfer', 'send', 'approve', 'grant')
    AND timestamp > NOW() - INTERVAL 1 HOUR
GROUP BY sender_domain
```

*Bayesian Authority Legitimacy:*
$$P(legitimate|factors) = \frac{P(factors|legitimate) \cdot P(legitimate)}{P(factors)}$$

Factors:
- time_of_day (off-hours reduces legitimacy)
- request_pattern (matches historical?)
- verification_attempted (user tried to verify?)

**Key Indicator: 1.3 Authority Impersonation Susceptibility**

*Observable:*
Failed SPF/DKIM checks correlated with user interactions

*Detection Logic:*
```
spoofed_authority_interactions = 
    COUNT(email_opened OR attachment_clicked OR reply_sent)
WHERE (spf_result = 'fail' OR dkim_result = 'fail')
    AND sender_claims_authority = TRUE
    
IF spoofed_authority_interactions > threshold THEN Yellow
```

*Response Protocol:*
- Level 1 (Automated): Block future emails from spoofed domain
- Level 2 (Semi-auto): Alert user, require re-training
- Level 3 (Manual): Investigate if credentials compromised

### Category 2: Temporal Vulnerabilities

**Data Sources:**
- Task management systems (Jira, ServiceNow)
- Code commit logs
- System access logs with timestamps
- Project management tools

**Key Indicator: 2.1 Urgency-Induced Bypass**

*Observable:*
Urgency index $U_i = \frac{\Delta t_{normal} - \Delta t_{urgent}}{\Delta t_{normal}}$

*Detection Logic:*
```
IF U_i > 0.5 THEN
    # 50% acceleration indicates urgency
    bypass_probability = poisson_regression(pressure, deadline_proximity)
    
λ = exp(β₀ + β₁·pressure + β₂·deadline_proximity)

IF λ > threshold_yellow THEN Yellow
IF λ > threshold_red THEN Red
```

*Calibration:*
- Collect normal task completion times by task type
- Identify "urgent" tasks via keywords, priority flags
- Calculate $U_i$ for each task
- Correlate with security exceptions, errors

**Key Indicator: 2.6 Temporal Exhaustion Patterns**

*Observable:*
Security effectiveness over circadian cycle

*Detection Logic - Circadian Model:*
$$E(t) = E_0 \cdot (1 + A \cdot \sin(\frac{2\pi(t - \phi)}{24}))$$

Where:
- $E(t)$ = Effectiveness at hour $t$
- $E_0$ = Baseline effectiveness
- $A$ = Amplitude (typically 0.2-0.3)
- $\phi$ = Phase shift (typically 3-4, peaking mid-afternoon)

*Implementation:*
```python
import numpy as np

def circadian_effectiveness(hour_of_day, baseline=1.0, amplitude=0.25, phase=3):
    """Calculate expected security effectiveness by hour"""
    return baseline * (1 + amplitude * np.sin(2*np.pi*(hour_of_day - phase)/24))

# Flag if actual effectiveness significantly below predicted
actual_effectiveness = incident_rate_by_hour  # Lower is better
predicted = circadian_effectiveness(current_hour)

if actual_effectiveness < (predicted - 2*std_dev):
    alert('Temporal exhaustion detected')
```

### Category 3: Social Influence Vulnerabilities

**Data Sources:**
- Email content and metadata
- Communication platforms (Slack, Teams)
- Network access patterns
- Behavioral analytics

**Key Indicator: 3.1 Reciprocity Exploitation**

*Observable:*
Favor exchange networks from communication analysis

*Detection Logic:*
```
Reciprocity Index R = Σ(w_ij · favor_ij)

where:
w_ij = relationship weight (derived from comm frequency)
favor_ij = detected favor exchange

Detection via NLP:
- Sentiment analysis for positive exchanges
- Pattern: favor granted → request made
- Time proximity (within 48 hours)

IF R > baseline + 2σ THEN Yellow
```

*NLP Pipeline:*
1. Extract email/chat content
2. Sentiment analysis (positive = potential favor)
3. Sequence detection: positive exchange → request
4. Graph analysis: favor networks
5. Correlation with security events

**Key Indicator: 3.3 Social Proof Manipulation**

*Observable:*
Claims of collective action in communications

*Detection Logic - BERT Embedding:*
```python
from transformers import BertTokenizer, BertModel
import torch

# Known social proof phrases
social_proof_phrases = [
    "everyone else has already",
    "all other departments have",
    "everyone in the team",
    "the rest of the organization"
]

# Compute embeddings
def detect_social_proof(text):
    tokens = tokenizer(text, return_tensors='pt')
    outputs = model(**tokens)
    text_embedding = outputs.last_hidden_state.mean(dim=1)
    
    # Compare to known patterns
    similarities = []
    for phrase in social_proof_phrases:
        phrase_tokens = tokenizer(phrase, return_tensors='pt')
        phrase_outputs = model(**phrase_tokens)
        phrase_embedding = phrase_outputs.last_hidden_state.mean(dim=1)
        
        similarity = cosine_similarity(text_embedding, phrase_embedding)
        similarities.append(similarity)
    
    max_similarity = max(similarities)
    return max_similarity > 0.85  # Threshold from testing
```

*Response:*
- Automatic enhanced verification required
- Flag transaction for manual review
- Alert recipient about social proof manipulation

### Category 5: Cognitive Overload Vulnerabilities

**Data Sources:**
- SIEM alert volumes
- Help desk ticket systems
- Error logs
- User behavior analytics

**Key Indicator: 5.1 Alert Fatigue**

*Observable:*
$$F_a = 1 - \frac{alerts_{investigated}}{alerts_{presented}}$$

*Temporal Model:*
$$F_a(t) = F_0 \cdot e^{\lambda \cdot alert\_rate \cdot t}$$

Where fatigue grows exponentially with alert rate and time

*Detection Logic:*
```python
def calculate_alert_fatigue(window_hours=24):
    """Calculate alert fatigue over time window"""
    alerts = query_alerts(last_n_hours=window_hours)
    
    presented = len(alerts)
    investigated = len([a for a in alerts if a.status == 'investigated'])
    
    fatigue = 1 - (investigated / presented) if presented > 0 else 0
    
    # Compare to baseline
    if fatigue > baseline_fatigue + 0.2:  # 20% increase
        return 'Yellow'
    elif fatigue > baseline_fatigue + 0.4:  # 40% increase
        return 'Red'
    else:
        return 'Green'
```

*Mitigation Response:*
- Automatic alert suppression for low-priority duplicates
- Consolidate related alerts
- Escalate critical alerts to avoid being lost
- Recommend analyst rotation/breaks

**Key Indicator: 5.7 Working Memory Overflow**

*Observable:*
Concurrent security requirements exceeding $7 \pm 2$ capacity

*Detection Logic:*
```
# Count concurrent security tasks
concurrent_requirements = [
    active_password_resets,
    pending_approvals,
    active_incidents,
    security_tools_monitoring,
    compliance_tasks
]

total = sum(concurrent_requirements)

IF 7 < total <= 9 THEN Yellow  # At capacity
IF total > 9 THEN Red  # Over capacity
```

*Intervention:*
- Consolidate tasks where possible
- Defer non-urgent items
- Assign additional resources
- Simplify workflows

### Category 9: AI-Specific Vulnerabilities

**Data Sources:**
- AI system confidence scores
- Human override logs
- AI interaction logs
- System trust metrics

**Key Indicator: 9.2 Automation Bias**

*Observable:*
Override rate when AI conflicts with human judgment

*Detection Logic:*
```
override_rate = overrides / (AI_recommendations_total)

IF override_rate < 0.1 THEN Yellow  # Too little questioning
IF override_rate < 0.05 THEN Red    # Dangerous compliance

# Also flag opposite extreme
IF override_rate > 0.8 THEN Yellow  # Too much distrust
```

*Balanced Range:*
Healthy override rate: 0.15 - 0.60 (questioning but trusting)

**Key Indicator: 9.7 AI Hallucination Acceptance**

*Observable:*
Correlation between AI confidence and human acceptance

*Detection Logic:*
```python
def detect_hallucination_risk():
    """Identify dangerous acceptance zones"""
    
    # Get AI recommendations with confidence scores
    ai_outputs = query_ai_recommendations()
    
    for output in ai_outputs:
        confidence = output.confidence_score
        human_accepted = output.human_accepted
        
        # Dangerous zone: low confidence, high acceptance
        if confidence < 0.6 and human_accepted:
            flag_risk(output, 'Red', 
                     'Low AI confidence accepted without verification')
        
        # Also risky: overconfident AI, blindly accepted
        if confidence > 0.95 and human_accepted and not output.human_reviewed:
            flag_risk(output, 'Yellow',
                     'Overconfident AI not independently verified')
```

## Bayesian Network Interdependencies

### Network Structure

CPF indicators form a Bayesian network capturing conditional dependencies:

$$P(I_1, ..., I_{100}) = \prod_{i=1}^{100} P(I_i | parents(I_i))$$

### Key Interdependencies

**Stress → Authority Compliance**
$P(1.1=Red | 7.1=Red) = 0.8$

Acute stress increases unquestioning compliance with authority

**Temporal Pressure → Cognitive Overload**
$P(5.x=Red | 2.x=Red) = 0.7$

Time pressure depletes cognitive resources, increasing overload

**Group Dynamics → Individual Masking**
$P(\neg 4.x | 6.x=Red) = 0.6$

Strong group dynamics can mask individual affective vulnerabilities

### Predictive Queries

**Given observed indicators, predict hidden vulnerabilities:**

```python
# Belief propagation example
def predict_hidden_vulnerabilities(observed_indicators):
    """Use Bayesian network to infer unobserved risks"""
    
    # Initialize network with priors
    network = build_cpf_bayesian_network()
    
    # Enter evidence
    for indicator_id, value in observed_indicators.items():
        network.set_evidence(indicator_id, value)
    
    # Run inference
    network.run_inference()
    
    # Extract predictions for unobserved indicators
    predictions = {}
    for indicator_id in range(1, 101):
        if indicator_id not in observed_indicators:
            prob_red = network.query(indicator_id, value='Red')
            if prob_red > 0.7:
                predictions[indicator_id] = {
                    'predicted_state': 'Red',
                    'confidence': prob_red
                }
    
    return predictions
```

## Response Protocol Framework

### Graduated Escalation

Responses based on severity and confidence:

$$R(s, c, t) = \begin{cases}
automatic & \text{if } s \cdot c > 0.8 \\
semi\_auto & \text{if } 0.5 < s \cdot c \leq 0.8 \\
manual & \text{if } s \cdot c \leq 0.5
\end{cases}$$

Where:
- $s$ = Severity score (0-1)
- $c$ = Confidence score (0-1)  
- $t$ = Time criticality

### Response Levels

**Level 1: Automatic (< 100ms)**
- Block suspicious transactions
- Isolate compromised accounts
- Trigger MFA challenges
- Initiate logging enhancement

**Level 2: Semi-Automatic (< 5 min)**
- Requires human approval
- Privilege suspension
- Transaction freezing
- Enhanced monitoring activation

**Level 3: Manual Investigation (< 1 hour)**
- Behavioral analysis required
- Threat hunting initiated
- Forensic data collection
- Root cause investigation

### Integration with SOAR

```python
# SOAR playbook pseudocode
def cpf_indicator_response(indicator_id, severity, confidence):
    """Automated response orchestration"""
    
    response_threshold = severity * confidence
    
    if response_threshold > 0.8:
        # Level 1: Automatic
        actions = [
            soar.block_user_transaction(user_id),
            soar.enable_enhanced_logging(user_id),
            soar.trigger_mfa_challenge(user_id),
            soar.alert_soc_analyst(priority='high')
        ]
        for action in actions:
            action.execute()
    
    elif response_threshold > 0.5:
        # Level 2: Semi-automatic
        approval_required = soar.request_approval(
            analyst_on_duty,
            recommended_actions=['suspend_privileges', 'freeze_transaction'],
            timeout=300  # 5 minutes
        )
        
        if approval_required.approved:
            execute_recommended_actions()
    
    else:
        # Level 3: Manual
        soar.create_investigation_ticket(
            indicator=indicator_id,
            severity=severity,
            assigned_to=threat_hunt_team
        )
```

## Deployment Methodology

### Phased Rollout

**Phase 1: Baseline (30 days)**
- Collect telemetry without alerting
- Establish baselines for all indicators
- Calibrate thresholds
- Validate data quality

**Phase 2: Pilot (10 indicators, 60 days)**
- Deploy highest-value indicators
- Focus on Category 1 (Authority) and Category 5 (Cognitive Load)
- Validate detection accuracy
- Refine response protocols

**Phase 3: Graduated Rollout (20 indicators/month)**
- Add categories progressively
- Allow SOC team to adapt
- Continuous calibration
- Feedback incorporation

**Phase 4: Full Operational Capability (Month 8)**
- All 100 indicators operational
- Bayesian network fully functional
- Automated responses optimized
- Continuous improvement cycle established

### Resource Requirements

**Storage:**
- ~1TB per 1000 users per year
- Primarily log retention for correlation

**Compute:**
- 16 cores per 10,000 users for real-time processing
- GPU acceleration optional for NLP workloads

**Personnel:**
- 1 SOC analyst per 50 indicators for maintenance/tuning
- 1 data scientist for Bayesian network maintenance
- Integration with existing SOC staffing

### Integration Points

**SIEM Integration (Syslog):**
```python
# Send CPF indicators to SIEM
def send_to_siem(indicator_data):
    syslog_message = format_cef(
        name='CPF_Indicator',
        severity=indicator_data['severity'],
        extension={
            'indicator_id': indicator_data['id'],
            'category': indicator_data['category'],
            'score': indicator_data['score'],
            'confidence': indicator_data['confidence']
        }
    )
    send_syslog(siem_host, syslog_message)
```

**STIX/TAXII for Threat Intelligence:**
```python
# Export CPF indicators as STIX
def export_stix_indicator(cpf_indicator):
    stix_indicator = STIXIndicator(
        type='indicator',
        pattern=cpf_indicator.detection_pattern,
        labels=['psychological-vulnerability'],
        confidence=cpf_indicator.confidence,
        cpf_category=cpf_indicator.category
    )
    publish_to_taxii(taxii_server, stix_indicator)
```

## Validation and Calibration

### Continuous Validation

Matthews Correlation Coefficient for binary classifiers:

$$V = \frac{TP \cdot TN - FP \cdot FN}{\sqrt{(TP + FP)(TP + FN)(TN + FP)(TN + FN)}}$$

**Synthetic Testing:**
- Inject known psychological conditions
- Measure detection accuracy
- Target: MCC > 0.7 for all indicators

### Drift Detection

**Kolmogorov-Smirnov Test:**
- Compare current distribution vs. baseline
- Trigger recalibration when $p < 0.05$

```python
from scipy.stats import ks_2samp

def detect_drift(current_data, baseline_data):
    """Detect if data distribution has drifted"""
    statistic, p_value = ks_2samp(current_data, baseline_data)
    
    if p_value < 0.05:
        trigger_recalibration()
        return True
    return False
```

### Calibration via Isotonic Regression

Ensures predicted probabilities match observed frequencies:

```python
from sklearn.isotonic import IsotonicRegression

def calibrate_probabilities(predicted_probs, actual_outcomes):
    """Calibrate probability estimates"""
    ir = IsotonicRegression(out_of_bounds='clip')
    calibrated_probs = ir.fit_transform(predicted_probs, actual_outcomes)
    return calibrated_probs
```

## Reference Materials

For additional technical details:
- `references/detection_algorithms.md` - Complete algorithm specifications
- `references/data_schemas.md` - Database and log format specifications
- `references/integration_examples.md` - Code samples for common integrations

## Common Implementation Use Cases

**"Deploy CPF indicators in our Splunk environment"**
- Extract Splunk-specific data source mappings
- Provide SPL (Splunk Processing Language) queries
- Configure alerting and dashboards
- Integration with Splunk SOAR

**"Create detection logic for Category 1 indicators"**
- Detailed algorithms for each indicator
- Data extraction queries
- Threshold specifications
- Response automation

**"Build Bayesian network for CPF interdependencies"**
- Network structure specification
- Conditional probability tables
- Inference engine implementation
- Integration with real-time data
