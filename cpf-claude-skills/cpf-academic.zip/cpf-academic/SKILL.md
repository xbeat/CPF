---
name: cpf-academic
description: Academic and research-focused CPF content creation. Use when writing academic papers, peer-reviewed articles, theoretical research documents, literature reviews, or scholarly presentations about the Cybersecurity Psychology Framework. Triggers on "academic paper", "research paper", "peer review", "theoretical foundation", "literature review", or scholarly/scientific writing requests.
---

# CPF Academic Research Skill

## Overview

This skill provides comprehensive academic and theoretical foundations for scholarly writing about the Cybersecurity Psychology Framework. It contains deep theoretical integration, formal academic argumentation structures, and research methodology guidance for producing peer-reviewed publications and scientific presentations.

## When to Use This Skill

**Use cpf-academic when:**
- Writing academic papers for journals or conferences
- Developing peer-reviewed research articles
- Creating theoretical literature reviews
- Writing scholarly grant proposals
- Preparing academic presentations with deep theoretical grounding
- Developing research methodology sections
- Arguing theoretical positions in formal academic contexts

**Use cpf-framework (base skill) when:**
- Creating business presentations
- Writing executive summaries
- General CPF communications
- Marketing materials

**Use cpf-implementation when:**
- Technical SOC deployment documentation
- Algorithm specifications
- Engineering implementation guides

## Academic Writing Principles for CPF

### Theoretical Argumentation Structure

CPF academic papers follow this argumentative arc:

1. **Problem Statement**: Human factors in 85% of breaches, yet interventions target conscious level
2. **Gap Identification**: Neuroscience shows decisions occur 300-500ms pre-consciously (Libet, Soon)
3. **Theoretical Innovation**: Integration of psychoanalysis + cognitive psychology for pre-cognitive assessment
4. **Methodological Contribution**: 100-indicator, ternary assessment system
5. **Validation Framework**: Hypothesis that pre-cognitive states predict breaches independent of technical controls

### Formal Academic Tone

**Characteristics:**
- Passive voice acceptable in methodology sections
- Present tense for established theory, past tense for specific studies
- Hedging language for claims requiring validation ("suggests", "indicates", "may")
- Definitive language for established findings ("demonstrates", "reveals")
- First-person plural acceptable ("we propose", "our framework")

**Example transformations:**

Informal: "CPF is better than traditional approaches"
Academic: "CPF offers theoretical advantages over traditional conscious-level interventions by addressing pre-cognitive decision processes demonstrated in neuroscience literature (Libet, 1983; Soon et al., 2008)"

Informal: "Organizations ignore insider threats"  
Academic: "Organizations exhibit systematic bias toward external threat perception, consistent with Bion's (1961) fight-flight basic assumption, resulting in inadequate insider threat assessment"

## Deep Theoretical Integration

### Psychoanalytic Theory - Extended Treatment

For academic papers, provide comprehensive theoretical grounding:

**Bion's Group Dynamics (1961)**

*Work group vs. Basic assumption group*
- Work group: Reality-oriented, task-focused, rational collaboration
- Basic assumption group: Unconscious fantasy dominates, anxiety-driven, reality-distorting

*Three basic assumptions with cybersecurity manifestations:*

**Dependency (baD):**
- Core dynamic: Unconscious fantasy of omnipotent protector
- Organizational manifestation: Over-reliance on security vendors, abdication of responsibility
- Vulnerability mechanism: Reduced vigilance due to magical thinking about protection
- Evidence markers: Vendor dependency language, passive security posture, "they'll handle it" attitudes
- Clinical example: Post-tool-implementation relaxation of other controls

**Fight-Flight (baF):**
- Core dynamic: Threat as external enemy requiring combat/avoidance  
- Organizational manifestation: Aggressive perimeter defense, insider threat denial
- Vulnerability mechanism: Blind spot for internal vulnerabilities while fortifying external defenses
- Evidence markers: Military metaphors, external attribution bias, avoidance of difficult security conversations
- Clinical example: Draconian policies driving shadow IT creation

**Pairing (baP):**
- Core dynamic: Future union/solution will provide salvation
- Organizational manifestation: Perpetual tool acquisition without addressing fundamentals
- Vulnerability mechanism: Never fully implementing current solutions while awaiting "real" answer
- Evidence markers: Continuous RFP processes, disappointment cycles, "next tool" hope
- Clinical example: Security tool graveyard with poor adoption rates

**Klein's Object Relations (1946)**

*Splitting mechanism:*
- Primitive defense dividing objects into "all good" or "all bad"
- Protects against anxiety of ambivalence (acknowledging good and bad in same object)
- In security: Insiders idealized, outsiders demonized; legacy "good", new "bad"

*Projective identification:*
- Unwanted self-aspects projected onto external objects
- Object then treated as if it embodies those characteristics
- In security: Organizational vulnerabilities projected onto "sophisticated attackers"

*Paranoid-schizoid vs. Depressive position:*
- Paranoid-schizoid: Splitting dominant, extreme anxiety, persecution fears
- Depressive: Integration of good/bad, capacity for concern, mourning loss
- Security maturity requires depressive position: acknowledging own vulnerabilities while maintaining function

**Winnicott's Transitional Space (1971)**

*Core concept:*
- Psychological area between internal fantasy and external reality
- Neither subjective nor objective, but intermediate
- Essential for play, creativity, cultural experience

*Digital environments as transitional space:*
- Cyberspace exhibits transitional characteristics
- Boundaries between real/imaginary blurred
- Identity more fluid than physical space
- Omnipotent fantasies flourish

*Security implications:*
- Reduced reality perception of digital actions
- Online disinhibition effect
- Avatar/identity confusion
- Play attitude conflicting with security caution

**Jung's Analytical Psychology (1969)**

*Shadow archetype:*
- Repressed, denied aspects of personality/collective
- Doesn't disappear but projects onto others
- Organizational shadow: Denied vulnerabilities, competitive aggression, surveillance capabilities

*Shadow projection in security:*
- Organization's qualities attributed to attackers
- Hackers mythologized with superhuman abilities (organization's omnipotent fantasies)
- Attackers carry organization's denied aggression
- Prevents realistic threat assessment

*Collective unconscious:*
- Inherited psychological patterns across humanity
- Manifest through archetypes
- In security: Warrior (aggressive postures), Trickster (hackers/defenders), Hero (incident responders)

### Cognitive Psychology - Extended Treatment

**Kahneman's Dual-Process Theory (2011)**

*System 1 characteristics:*
- Automatic, fast, unconscious
- Pattern recognition based
- Low effort, always operative
- Evolutionarily older
- Error-prone in novel situations
- Dominant under cognitive load/time pressure

*System 2 characteristics:*
- Controlled, slow, conscious
- Rule-based reasoning
- High effort, requires activation
- Evolutionarily newer
- Better for novel problems
- Requires cognitive resources

*Security implications:*
- Most security decisions occur under conditions favoring System 1
- Training targets System 2 but decisions made by System 1
- Solution: Design for System 1 (intuitive) not against it (requiring deliberation)

**Prospect Theory (Kahneman & Tversky, 1979)**

*Loss aversion:*
- Losses loom larger than equivalent gains (ratio ~2:1)
- Pain of losing $100 > pleasure of gaining $100
- Security implication: Breach fear < resistance to security investment cost

*Framing effects:*
- Identical information, different frames → different decisions
- Positive frame: "Prevents 95% of attacks" 
- Negative frame: "Fails against 5% of attacks"
- Different responses despite identical information

*Reference point dependency:*
- Decisions relative to reference point, not absolute
- Security: Current state as reference makes changes feel like losses

**Cognitive Biases Detailed**

*Availability heuristic:*
- Judging frequency by ease of recall
- Recent, vivid events overweighted
- Security: Last major breach over-influences strategy

*Confirmation bias:*
- Seeking information confirming existing beliefs
- Ignoring disconfirming evidence
- Security: Security hypotheses never properly tested

*Authority bias (Milgram, 1974):*
- Over-trusting authority figures
- 65% administered potentially lethal shocks when instructed
- Security: Unquestioned executive/vendor compliance

*Sunk cost fallacy:*
- Continuing failed course due to past investment
- Rational: Future decisions ignore past costs
- Actual: "We've invested $2M, must make it work"

### Neuroscience Foundations - Extended

**Libet's Experiments (1983)**

*Methodology:*
- Measured readiness potential (brain activity preceding voluntary movement)
- Participants reported moment of conscious decision
- Found readiness potential preceded awareness by 300-500ms

*Implications:*
- Conscious will may be post-hoc interpretation
- Brain initiates action before conscious awareness
- "Free will" more complex than subjective experience suggests

*Security relevance:*
- Click decision initiated pre-consciously
- Phishing susceptibility determined before conscious evaluation
- Training conscious analysis insufficient

**Soon et al. (2008)**

*Methodology:*
- fMRI during decision-making tasks
- Prediction of decisions up to 10 seconds before awareness
- Identified predictive brain regions (frontopolar, parietal cortex)

*Findings:*
- Unconscious determinants of "free" decisions
- Pattern decodable from brain activity
- Conscious decision feeling does not equal actual timing

**LeDoux's Emotional Pathways (2000)**

*Dual-route processing:*
- Low road: Thalamus → Amygdala (fast, crude)
- High road: Thalamus → Cortex → Amygdala (slow, detailed)

*Security implications:*
- Threat detection activates before conscious analysis
- Amygdala response (fear/stress) overrides prefrontal reasoning
- Under threat, emotional circuits dominate

## Research Methodology Guidance

### CPF Validation Hypothesis

**Primary Hypothesis:**
Organizations scoring high (Red) on CPF indicators will experience significantly more security incidents than low-scoring (Green) organizations, independent of technical control maturity.

**This tests:**
- Pre-cognitive psychological states predict security outcomes
- Prediction occurs beyond technical measures
- CPF provides value-add over current frameworks

### Study Design Considerations

**For empirical validation studies:**

1. **Sample Selection**
   - Minimum 50 organizations for statistical power
   - Diverse sectors for generalizability
   - Control for organization size, industry, geography

2. **CPF Assessment**
   - Trained assessors (blind to outcome)
   - Ternary scoring (Green/Yellow/Red) per indicator
   - Aggregate scoring per category and overall

3. **Outcome Measurement**
   - Incident count (6-month follow-up)
   - Incident severity scoring
   - Normalized by organization size

4. **Technical Control Baseline**
   - NIST CSF maturity assessment
   - Control as covariate in analysis
   - Demonstrate CPF incremental validity

5. **Statistical Analysis**
   - Regression: Incidents ~ CPF_score + Technical_maturity
   - Test: CPF_score coefficient significantly > 0
   - Control for covariates (size, sector, geography)

### Ethical Considerations

**Critical for academic publications:**

1. **Privacy Protection**
   - Aggregate patterns only, never individual profiling
   - Anonymization of organizational data
   - IRB approval for human subjects research

2. **Informed Consent**
   - Clear explanation of assessment purpose
   - Voluntary participation
   - Right to withdraw

3. **Potential Harms**
   - Psychological assessment could create anxiety
   - Mitigation: Frame as organizational not individual
   - Provide actionable recommendations

4. **Transparency**
   - Full methodology disclosure
   - Limitations acknowledged
   - Competing interests declared

## Academic Writing Examples

### Abstract Structure

**CPF abstracts follow IMRaD abbreviated:**

We present the Cybersecurity Psychology Framework (CPF), [INNOVATION] a novel interdisciplinary model integrating psychoanalytic theory and cognitive psychology for pre-cognitive vulnerability assessment. [GAP] Unlike traditional conscious-level interventions, CPF addresses the 300-500ms pre-conscious decision window demonstrated in neuroscience. [METHOD] The framework comprises 100 indicators across 10 categories assessed through ternary rating. [IMPLICATION] CPF enables predictive rather than reactive security strategies by mapping unconscious organizational dynamics to attack vectors.

### Introduction Paragraph Pattern

**Problem → Evidence → Gap → Solution**

Example:
"Despite exponential growth in cybersecurity investment [PROBLEM], human factors contribute to 85% of successful breaches [EVIDENCE]. Current frameworks target conscious decision-making [CURRENT APPROACH], yet neuroscience demonstrates decisions occur 300-500ms pre-consciously [GAP/CONTRADICTION]. The Cybersecurity Psychology Framework addresses this gap through systematic integration of psychoanalytic and cognitive theories [SOLUTION], enabling assessment of pre-cognitive vulnerability states."

### Citation Density

**Academic CPF papers maintain high citation density:**
- Introduction: 3-5 citations per paragraph
- Theoretical foundation: 5-10 citations per section
- Methodology: 2-3 citations for established methods
- Discussion: 3-5 citations per paragraph

**Primary sources preferred:**
- Bion (1961) not secondary interpretations
- Kahneman (2011) not popularizations
- Libet (1983), Soon (2008) for neuroscience

## Reference Materials

For comprehensive theoretical detail, consult:
- `references/extended_theory.md` - Full psychoanalytic and cognitive psychology theory
- `references/research_methodology.md` - Detailed study design and statistical approaches
- `references/academic_examples.md` - Sample abstracts, introductions, discussion sections

## Common Academic Use Cases

**"Write an academic paper on CPF for Journal of Cybersecurity"**
- Full theoretical grounding
- Literature review positioning CPF
- Detailed methodology
- Discussion of limitations and future research
- High citation density
- Formal academic tone

**"Create a conference presentation for academic audience"**
- Theoretical credibility emphasized
- Research methodology highlighted
- Preliminary validation results if available
- Future research agenda
- Academic tone maintained

**"Develop a grant proposal for CPF validation study"**
- Theoretical significance established
- Research gap clearly defined
- Methodology rigorously specified
- Expected contributions articulated
- Budget justified by research design
